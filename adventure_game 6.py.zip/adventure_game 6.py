from time import sleep
import random

monster_hell = False
stairs_exit = False

def print_pause(message, sleep_time=2.):
    print(message)
    sleep(sleep_time)

def set_defaults():
    global monster_hell, stairs_exit
    monster_hell = False
    stairs_exit = False

def introduction():
    print_pause("You are entering a dark basement.")
    print_pause("Everything is so quiet. "
                "Maybe too quiet ?")
    print_pause("And suddenly you hear something. "
                "The noise can either come from the door at your left or from the the one on the right")

def lose(message):
    print(message)
    print("\nYou lose.")
    play_again = input("Do you want to play again? (y/n): ")
    while play_again not in ['y', 'n']:
        play_again = input("Invalid input. Do you want to play again? (y/n): ")

    if play_again == 'y':
        print()
        run()


def win():
    global stairs_exit
    print_pause("You get a gun and use it")
    print_pause("Awesome ! You just killed the monster")

    if not stairs_exit:
        print_pause("You just access some stairs allowing you to escape the basement")

    print()
    print("You won!")

    play_again = input("Do you want to play again? (y/n): ")
    while play_again not in ['y', 'n']:
        play_again = input("Invalid input. Do you want to play again? (y/n): ")

    if play_again == 'y':
        print()
        run()


def up_or_down():
    print_pause("Now there are two paths in front of you "
                "one that goes up and the other that goes down")
    choice = input("Which way do you choose? 1-upward path, 2-downward path. "
                   "(1/2): ")
    while choice not in ['1', '2']:
        choice = input("Invalid input. Which way do you choose? "
                       "1-upward path, 2-downward path. (1/2): ")

    if choice == '1':
        upward_choice()
    else:
        downward_choice()

def upward_choice():
    global monster_hell
    print_pause("You end up in a graveyard.")
    print_pause("And when you look closely to one of them")
    print_pause("The monster appears!")
    print_pause("You start to run toward the other path but do you have enough time ?")
    choice = input("Do you want to run or to fight? 1-run, 2-fight. (1/2): ")
    while choice not in ['1', '2']:
        choice = input("Invalid input. Do you want to run or to fight?"
                       " 1-run, 2-fight. (1/2): ")

    if choice == '1':
        if random.randint(1,10) > 3:  # 70% chance of surviving
            monster_hell = True
            print_pause("Wow, it was a close one !")
            path_choice()
        else:
            print_pause("You start running")
            lose("But the monster hits you twice."
                 "Game Over.")
    else:
        print_pause("You take back your gun and strat aiming at the monster.")
        lose("Too late he already hits you, Game Over.")


def path_choice():
    print_pause("You continue your journey and end up in an empty room with only two doors.")
    print_pause("One on the left and one of the right.")
    choice = input("Which way do you choose? 1-left, 2-right. (1/2): ")
    while choice not in ['1', '2']:
        choice = input("Invalid input. Which way do you choose? "
                       "1-left, 2-right. (1/2): ")

    if choice == '1':
        left_choice()
    else:
        right_choice()

def right_choice():
    global monster_hell
    print_pause("You open the door")
    if stairs_exit:
        if monster_hell:  
            print_pause("The monster is here again")
            
            choice = input("Do you want to continue to walk "
                           "or to fight? 1-walk, 2-fight. (1/2): ")
            while choice not in ['1', '2']:
                choice = input(
                    "Invalid input. Do you want to continue to walk "
                    "or to fight? 1-walk, 2-fight. (1/2): ")

            if choice == '1':
                print_pause("You went back to the other door.")
                print_pause("You take the left door")
                left_choice()
            else:
                if random.randint(1,10) > 6:
                    win()
                else:
                    print_pause("You foud another gun bigger this time and more powerful ")
                    lose(
                        "But one again the monster is too smart he followed you and hit you before you can pull the trigger.")
        else:  # the monster didn't hear you
            print_pause("The monster is fighting with another adventurer")
            choice = input("Do you want to escape or to fight? "
                           "1-escape, 2-fight. (1/2): ")
            while choice not in ['1', '2']:
                choice = input(
                    "Invalid input. Do you want to escape or to fight? "
              
                    "1-escape, 2-fight. (1/2): ")

            if choice == '1':
                escape_choice()
            else:
                win()
    else:
        if monster_hear:  # the monster hears you
            print_pause("The monster is still here")
            choice = input("Do you want to go back in the previous room or"
                           " to fight? "
                           "1-go back, 2-fight. (1/2): ")
            while choice not in ['1', '2']:
                choice = input(
                    "Invalid input. Do you want to go back in the previous room "
                    "or to fight? "
                    "1-go back, 2-fight. (1/2): ")

            if choice == '1':
                print_pause("You went back to the previous room.")
                print_pause("You now decide to take back the right door.")
                right_choice()
            else:
                if monster_hell:
                    if random.randint(1,10) > 5:
                        win()
                    else:
                        print_pause("You found a gun and you are about the piull the trigger")
                        lose(
                            "But the monster hears you once again and kills you Game Over.")
                else:
                    win()
        else:
            print_pause("The monster is fighting with another adventurer")
            choice = input("Do you want to go back into the previous room"
                           "or to fight? 1-go back, 2-fight. (1/2): ")
            while choice not in ['1', '2']:
                choice = input(
                    "Invalid input. Do you want to go back into the previous room "
                    "or to fight? 1-go back, 2-fight. (1/2): ")

            if choice == '1':
                print_pause("You went back to the right door.")
                print_pause("you take the right choice")
                right_choice()
            else:
                win()

def right_choice():
    print_pause("You open the door on the right")
    print_pause("You look around and see two exits, one on the left and one on the right")
    print_pause("You can even see daylight from both doors")
    left_or_right()

def left_or_right():
    print_pause("You see two exits, one on the left and one on the right.")
    print_pause("But the monster could still come to one of this exit.")
    choice = input("Which way do you choose? 1-left, 2-right. (1/2): ")
    while choice not in ['1', '2']:
        choice = input("Invalid input. Which way do you choose? "
                       "1-left, 2-right. (1/2): ")

    if choice == '1':
        left_choice()
    else:
        right_choice()

def right_choice():
    print_pause("The way is clear you can escape the basement!")
    print_pause("Oh wait no the monster is still here behind you.")
    print_pause("He beats you to death, Game Over.")
    

def run():
    set_defaults()
    introduction()
    gate_or_path()

run()
